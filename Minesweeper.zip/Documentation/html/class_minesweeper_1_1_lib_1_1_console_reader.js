var class_minesweeper_1_1_lib_1_1_console_reader =
[
    [ "ReadLine", "class_minesweeper_1_1_lib_1_1_console_reader.html#ae6bb2ed667d1290078a0f9bb7b53e9a8", null ],
    [ "WaitForKey", "class_minesweeper_1_1_lib_1_1_console_reader.html#a92588508515c5082d628e9f56672e863", null ]
];