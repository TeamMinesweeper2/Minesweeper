var interface_minesweeper_1_1_lib_1_1_i_cell_position =
[
    [ "Col", "interface_minesweeper_1_1_lib_1_1_i_cell_position.html#aca8beb37824e81653e0b2425a2dd475e", null ],
    [ "Row", "interface_minesweeper_1_1_lib_1_1_i_cell_position.html#a41fc9d6cadddc3e5c66d01746f74f823", null ]
];