var interface_minesweeper_1_1_lib_1_1_i_user_input_reader =
[
    [ "ReadLine", "interface_minesweeper_1_1_lib_1_1_i_user_input_reader.html#a58da9817d2e63a510cf833ce7d65f008", null ],
    [ "WaitForKey", "interface_minesweeper_1_1_lib_1_1_i_user_input_reader.html#a54b4a65a7cea8be31dc99a6330be6f51", null ]
];