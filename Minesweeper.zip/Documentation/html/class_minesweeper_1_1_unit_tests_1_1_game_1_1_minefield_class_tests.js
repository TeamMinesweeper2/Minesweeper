var class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests =
[
    [ "AllNeighborMinesPropertyShouldReturnCorrectTwoDimensionalArray", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a619d46f5e743894b8b2b651c361aafff", null ],
    [ "GetImageShouldReturnProperTwoDimensionalArrayOfCellImageEnumsFalseShowAll", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#af51b1f30a903fde456a6b258aab96a47", null ],
    [ "GetImageShouldReturnProperTwoDimensionalArrayOfCellImageEnumsTrueShowAll", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a9c6d456987ba9a68d4795361b58c63c9", null ],
    [ "Initialize", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a052364795ce9d9654108dafa6000f8b9", null ],
    [ "MinefieldConstructorRecievingIncorrectColumnNumberShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a1e5e4ae4759228570a0af96fb1d1845f", null ],
    [ "MinefieldConstructorRecievingIncorrectMinesNumberShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a91a4494bbf4cf458e92ec87392029037", null ],
    [ "MinefieldConstructorRecievingIncorrectRowNumberShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#af73a594d83efcadb361e48fdb7254415", null ],
    [ "MinefieldConstructorRecievingNullRandomGeneratorProviderShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a85afc5fac3afefecd08fc1af0a3e3ac7", null ],
    [ "OpenCellHandlerShouldMissTheFirstMine", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a5cb5109809a2da50ad015a3c3a334a6e", null ],
    [ "OpenCellHandlerShouldReturnCorrectStateEnumerationValueAlreadyOpened", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a12ca2a92bc3e3f04cfc33fd6a2aa9a70", null ],
    [ "OpenCellHandlerShouldReturnCorrectStateEnumerationValueBoom", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a77bc1e8de7adf8b8edaf949507ec0e4a", null ],
    [ "OpenCellHandlerShouldReturnCorrectStateEnumerationValueNormal", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#ac496494fbd371f400aa91a0c12753efe", null ],
    [ "OpenCellHandlerShouldReturnCorrectStateEnumerationValueNormalWithoutChainedOpening", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a4cab3954d245012a721e2a3364a3f471", null ],
    [ "OpenCellHandlerShouldReturnCorrectStateEnumerationValueOutOfRange", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_minefield_class_tests.html#a0b40e8aa707d0260c24d07675ddaa427", null ]
];