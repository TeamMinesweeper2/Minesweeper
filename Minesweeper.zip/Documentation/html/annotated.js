var annotated =
[
    [ "Minesweeper", "namespace_minesweeper.html", "namespace_minesweeper" ]
];