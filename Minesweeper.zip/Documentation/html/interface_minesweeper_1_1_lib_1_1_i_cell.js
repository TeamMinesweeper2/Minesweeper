var interface_minesweeper_1_1_lib_1_1_i_cell =
[
    [ "AddMine", "interface_minesweeper_1_1_lib_1_1_i_cell.html#a0befb554376beed982e468052e7c0ed6", null ],
    [ "Disarm", "interface_minesweeper_1_1_lib_1_1_i_cell.html#a12556fc759e102491c7ce2c432bd0dec", null ],
    [ "OpenCell", "interface_minesweeper_1_1_lib_1_1_i_cell.html#aa7b5d6db30495f23c0aa595e95aa16ae", null ],
    [ "ToggleFlag", "interface_minesweeper_1_1_lib_1_1_i_cell.html#acb11d64a47cb3176d2fe42a093958e49", null ],
    [ "IsFlagged", "interface_minesweeper_1_1_lib_1_1_i_cell.html#ad854c4d0c51388abb1b11634184ba361", null ],
    [ "IsMined", "interface_minesweeper_1_1_lib_1_1_i_cell.html#a4bd673766caa3ba4975bcbdc092c61c6", null ],
    [ "IsOpened", "interface_minesweeper_1_1_lib_1_1_i_cell.html#a02ffb839dc8dc60f261628916e2ac62a", null ]
];