var searchData=
[
  ['scoreboard',['ScoreBoard',['../class_minesweeper_1_1_game_1_1_score_board.html',1,'Minesweeper::Game']]],
  ['scoreboardtests',['ScoreBoardTests',['../class_minesweeper_1_1_unit_tests_1_1_game_1_1_score_board_tests.html',1,'Minesweeper::UnitTests::Game']]],
  ['shuffleextensiontest',['ShuffleExtensionTest',['../class_minesweeper_1_1_unit_tests_1_1_common_1_1_shuffle_extension_test.html',1,'Minesweeper::UnitTests::Common']]]
];
