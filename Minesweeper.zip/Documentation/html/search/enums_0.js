var searchData=
[
  ['cellactionresult',['CellActionResult',['../namespace_minesweeper.html#af85e37deff295959aea34f4226d8ba93',1,'Minesweeper']]],
  ['cellimage',['CellImage',['../namespace_minesweeper.html#adf92d608047dafd69d16008492d317bd',1,'Minesweeper']]]
];
