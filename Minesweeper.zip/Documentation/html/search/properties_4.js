var searchData=
[
  ['openedcellscount',['OpenedCellsCount',['../class_minesweeper_1_1_game_1_1_minefield.html#a3fabf570d9045ea288bb06fd1ecea287',1,'Minesweeper::Game::Minefield']]]
];
