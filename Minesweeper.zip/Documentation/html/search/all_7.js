var searchData=
[
  ['icell',['ICell',['../interface_minesweeper_1_1_lib_1_1_i_cell.html',1,'Minesweeper::Lib']]],
  ['icellposition',['ICellPosition',['../interface_minesweeper_1_1_lib_1_1_i_cell_position.html',1,'Minesweeper::Lib']]],
  ['icommand',['ICommand',['../interface_minesweeper_1_1_game_1_1_i_command.html',1,'Minesweeper::Game']]],
  ['irandomgeneratorprovider',['IRandomGeneratorProvider',['../interface_minesweeper_1_1_lib_1_1_i_random_generator_provider.html',1,'Minesweeper::Lib']]],
  ['irenderer',['IRenderer',['../interface_minesweeper_1_1_lib_1_1_i_renderer.html',1,'Minesweeper::Lib']]],
  ['isdisarmed',['IsDisarmed',['../class_minesweeper_1_1_game_1_1_minefield.html#a41bbc89242ced88cca3171e0c57fb50e',1,'Minesweeper::Game::Minefield']]],
  ['isflagged',['IsFlagged',['../class_minesweeper_1_1_lib_1_1_cell.html#ad0b6f5feaeb0f065246e450f853ada61',1,'Minesweeper.Lib.Cell.IsFlagged()'],['../interface_minesweeper_1_1_lib_1_1_i_cell.html#ad854c4d0c51388abb1b11634184ba361',1,'Minesweeper.Lib.ICell.IsFlagged()']]],
  ['isinsidematrix',['IsInsideMatrix',['../class_minesweeper_1_1_game_1_1_minefield.html#a1675fa664921d1110b8e2443645ce737',1,'Minesweeper::Game::Minefield']]],
  ['ismined',['IsMined',['../class_minesweeper_1_1_lib_1_1_cell.html#a900f81faa7bcc6021be178401b57763c',1,'Minesweeper.Lib.Cell.IsMined()'],['../interface_minesweeper_1_1_lib_1_1_i_cell.html#a4bd673766caa3ba4975bcbdc092c61c6',1,'Minesweeper.Lib.ICell.IsMined()']]],
  ['isopened',['IsOpened',['../class_minesweeper_1_1_lib_1_1_cell.html#a78511856244d5f3ed2c876b94d55fcd3',1,'Minesweeper.Lib.Cell.IsOpened()'],['../interface_minesweeper_1_1_lib_1_1_i_cell.html#a02ffb839dc8dc60f261628916e2ac62a',1,'Minesweeper.Lib.ICell.IsOpened()']]],
  ['iuimanager',['IUIManager',['../interface_minesweeper_1_1_game_1_1_i_u_i_manager.html',1,'Minesweeper::Game']]],
  ['iuserinputreader',['IUserInputReader',['../interface_minesweeper_1_1_lib_1_1_i_user_input_reader.html',1,'Minesweeper::Lib']]]
];
