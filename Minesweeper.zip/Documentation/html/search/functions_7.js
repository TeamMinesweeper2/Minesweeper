var searchData=
[
  ['isdisarmed',['IsDisarmed',['../class_minesweeper_1_1_game_1_1_minefield.html#a41bbc89242ced88cca3171e0c57fb50e',1,'Minesweeper::Game::Minefield']]],
  ['isinsidematrix',['IsInsideMatrix',['../class_minesweeper_1_1_game_1_1_minefield.html#a1675fa664921d1110b8e2443645ce737',1,'Minesweeper::Game::Minefield']]]
];
