var searchData=
[
  ['isflagged',['IsFlagged',['../class_minesweeper_1_1_lib_1_1_cell.html#ad0b6f5feaeb0f065246e450f853ada61',1,'Minesweeper.Lib.Cell.IsFlagged()'],['../interface_minesweeper_1_1_lib_1_1_i_cell.html#ad854c4d0c51388abb1b11634184ba361',1,'Minesweeper.Lib.ICell.IsFlagged()']]],
  ['ismined',['IsMined',['../class_minesweeper_1_1_lib_1_1_cell.html#a900f81faa7bcc6021be178401b57763c',1,'Minesweeper.Lib.Cell.IsMined()'],['../interface_minesweeper_1_1_lib_1_1_i_cell.html#a4bd673766caa3ba4975bcbdc092c61c6',1,'Minesweeper.Lib.ICell.IsMined()']]],
  ['isopened',['IsOpened',['../class_minesweeper_1_1_lib_1_1_cell.html#a78511856244d5f3ed2c876b94d55fcd3',1,'Minesweeper.Lib.Cell.IsOpened()'],['../interface_minesweeper_1_1_lib_1_1_i_cell.html#a02ffb839dc8dc60f261628916e2ac62a',1,'Minesweeper.Lib.ICell.IsOpened()']]]
];
