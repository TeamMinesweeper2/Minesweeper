var searchData=
[
  ['randomgeneratorprovider',['RandomGeneratorProvider',['../class_minesweeper_1_1_lib_1_1_random_generator_provider.html',1,'Minesweeper::Lib']]],
  ['readinput',['ReadInput',['../interface_minesweeper_1_1_game_1_1_i_u_i_manager.html#ac2d51aed7d1d677c899fa596becc6afb',1,'Minesweeper.Game.IUIManager.ReadInput()'],['../class_minesweeper_1_1_game_1_1_u_i_manager.html#abf069aaf0ff743c8b5f27ea3dba46be4',1,'Minesweeper.Game.UIManager.ReadInput()']]],
  ['readline',['ReadLine',['../class_minesweeper_1_1_lib_1_1_console_reader.html#ae6bb2ed667d1290078a0f9bb7b53e9a8',1,'Minesweeper.Lib.ConsoleReader.ReadLine()'],['../interface_minesweeper_1_1_lib_1_1_i_user_input_reader.html#a58da9817d2e63a510cf833ce7d65f008',1,'Minesweeper.Lib.IUserInputReader.ReadLine()']]],
  ['row',['Row',['../struct_minesweeper_1_1_lib_1_1_cell_pos.html#adb4d01bbbda584e580a188aa48173834',1,'Minesweeper.Lib.CellPos.Row()'],['../interface_minesweeper_1_1_lib_1_1_i_cell_position.html#a41fc9d6cadddc3e5c66d01746f74f823',1,'Minesweeper.Lib.ICellPosition.Row()']]],
  ['run',['Run',['../class_minesweeper_1_1_game_1_1_engine.html#ab6a67e0cd6cad74cce9c7606831a5829',1,'Minesweeper::Game::Engine']]]
];
