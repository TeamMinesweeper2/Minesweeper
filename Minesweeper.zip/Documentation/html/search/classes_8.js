var searchData=
[
  ['uimanager',['UIManager',['../class_minesweeper_1_1_game_1_1_u_i_manager.html',1,'Minesweeper::Game']]],
  ['uimanagertest',['UIManagerTest',['../class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html',1,'Minesweeper::UnitTests::Game']]]
];
