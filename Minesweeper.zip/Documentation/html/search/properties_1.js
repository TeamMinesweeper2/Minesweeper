var searchData=
[
  ['cells',['Cells',['../class_minesweeper_1_1_game_1_1_minefield.html#a6308163a3dc8ed1f5681de4bbd184788',1,'Minesweeper::Game::Minefield']]],
  ['col',['Col',['../struct_minesweeper_1_1_lib_1_1_cell_pos.html#a0188f8cda7f5c928a7c0e3f252878da2',1,'Minesweeper.Lib.CellPos.Col()'],['../interface_minesweeper_1_1_lib_1_1_i_cell_position.html#aca8beb37824e81653e0b2425a2dd475e',1,'Minesweeper.Lib.ICellPosition.Col()']]]
];
