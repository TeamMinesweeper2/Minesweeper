var searchData=
[
  ['uimanager',['UIManager',['../class_minesweeper_1_1_game_1_1_u_i_manager.html',1,'Minesweeper::Game']]],
  ['uimanager',['UIManager',['../class_minesweeper_1_1_game_1_1_u_i_manager.html#a424a2a585050b3c85d119d84c4ba2b80',1,'Minesweeper.Game.UIManager.UIManager()'],['../class_minesweeper_1_1_game_1_1_u_i_manager.html#a996444e4a3c298158ab07d21f48c7307',1,'Minesweeper.Game.UIManager.UIManager(IRenderer renderer, IUserInputReader inputReader)']]],
  ['uimanagertest',['UIManagerTest',['../class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html',1,'Minesweeper::UnitTests::Game']]]
];
