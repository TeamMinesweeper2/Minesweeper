var searchData=
[
  ['addmine',['AddMine',['../class_minesweeper_1_1_lib_1_1_cell.html#a64366640c2cb5425cc73817827d291c4',1,'Minesweeper.Lib.Cell.AddMine()'],['../interface_minesweeper_1_1_lib_1_1_i_cell.html#a0befb554376beed982e468052e7c0ed6',1,'Minesweeper.Lib.ICell.AddMine()']]],
  ['addscore',['AddScore',['../class_minesweeper_1_1_game_1_1_score_board.html#acb8f228b35af71c1bd91012e32be4283',1,'Minesweeper::Game::ScoreBoard']]]
];
