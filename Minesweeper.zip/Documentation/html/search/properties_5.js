var searchData=
[
  ['row',['Row',['../struct_minesweeper_1_1_lib_1_1_cell_pos.html#adb4d01bbbda584e580a188aa48173834',1,'Minesweeper.Lib.CellPos.Row()'],['../interface_minesweeper_1_1_lib_1_1_i_cell_position.html#a41fc9d6cadddc3e5c66d01746f74f823',1,'Minesweeper.Lib.ICellPosition.Row()']]]
];
