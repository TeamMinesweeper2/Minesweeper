var searchData=
[
  ['next',['Next',['../interface_minesweeper_1_1_lib_1_1_i_random_generator_provider.html#a0f49fa42c327f257a83bfb9264cb9124',1,'Minesweeper.Lib.IRandomGeneratorProvider.Next(int min, int max)'],['../interface_minesweeper_1_1_lib_1_1_i_random_generator_provider.html#a582bbebd6de2ecdded37c76b35c74a66',1,'Minesweeper.Lib.IRandomGeneratorProvider.Next(int max)'],['../class_minesweeper_1_1_lib_1_1_random_generator_provider.html#a53e1e507758a05548dd09e14c81af8d4',1,'Minesweeper.Lib.RandomGeneratorProvider.Next(int minNumber, int maxNumber)'],['../class_minesweeper_1_1_lib_1_1_random_generator_provider.html#afabb9a038955a531abcb19cb0c6b77a3',1,'Minesweeper.Lib.RandomGeneratorProvider.Next(int maxNumber)']]]
];
