var searchData=
[
  ['icell',['ICell',['../interface_minesweeper_1_1_lib_1_1_i_cell.html',1,'Minesweeper::Lib']]],
  ['icellposition',['ICellPosition',['../interface_minesweeper_1_1_lib_1_1_i_cell_position.html',1,'Minesweeper::Lib']]],
  ['icommand',['ICommand',['../interface_minesweeper_1_1_game_1_1_i_command.html',1,'Minesweeper::Game']]],
  ['irandomgeneratorprovider',['IRandomGeneratorProvider',['../interface_minesweeper_1_1_lib_1_1_i_random_generator_provider.html',1,'Minesweeper::Lib']]],
  ['irenderer',['IRenderer',['../interface_minesweeper_1_1_lib_1_1_i_renderer.html',1,'Minesweeper::Lib']]],
  ['iuimanager',['IUIManager',['../interface_minesweeper_1_1_game_1_1_i_u_i_manager.html',1,'Minesweeper::Game']]],
  ['iuserinputreader',['IUserInputReader',['../interface_minesweeper_1_1_lib_1_1_i_user_input_reader.html',1,'Minesweeper::Lib']]]
];
