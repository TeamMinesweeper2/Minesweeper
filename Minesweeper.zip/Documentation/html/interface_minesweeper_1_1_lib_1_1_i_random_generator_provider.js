var interface_minesweeper_1_1_lib_1_1_i_random_generator_provider =
[
    [ "Next", "interface_minesweeper_1_1_lib_1_1_i_random_generator_provider.html#a0f49fa42c327f257a83bfb9264cb9124", null ],
    [ "Next", "interface_minesweeper_1_1_lib_1_1_i_random_generator_provider.html#a582bbebd6de2ecdded37c76b35c74a66", null ]
];