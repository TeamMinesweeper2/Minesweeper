var class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test =
[
    [ "ClearCommandLineWithNullParameterShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a508682d8da77a4e9f1fba7a96d11d36a", null ],
    [ "DisplayEndShouldPrintInTheConsoleProperMessage", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a930b1aad92fdc0ab3dfef625eb37d450", null ],
    [ "DisplayEndWhenMessageIsEmptyShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a10a158aaef78f4cd5ffa34d4ee37383b", null ],
    [ "DisplayEndWhenMessageIsNullShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a19a0a251d428e09e0f4e37142d53e7b9", null ],
    [ "DisplayEndWhenOpenedCellsIsNegativeShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a7f0fde3bc39476048907edf038984c4f", null ],
    [ "DisplayErrorShouldCallRendererCorrectly", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#ae664d293a4d7540900737e632a69e4f8", null ],
    [ "DisplayErrorShouldPrintInTheConsoleProperMessage", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#aa3e6d09173cd088d2e6b6fed42a724d3", null ],
    [ "DisplayErrorWhenMessageIsEmptyShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a733a53d44b88edd65b980dc0a53569f8", null ],
    [ "DisplayErrorWhenMessageIsNullShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a8e65c909b924e62e1f4f4d2d98ef03e2", null ],
    [ "DisplayHighScoresShouldPrintProperListInTheConsole", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a8b1a2dbef62b42a328c60fc5bd42040d", null ],
    [ "DisplayHighScoresWhenArgumentIsNullShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a8e6c3136537d37b82c6b3daf59d56bb3", null ],
    [ "DisplayIntroShouldPrintInTheConsoleProperMessage", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a27d6d58ca5723300d0499d4175184a09", null ],
    [ "DisplayIntroWhenMessageIsNullShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#ae378eb70da7d6c8bb8a61172b3cf1ede", null ],
    [ "DrawGameFieldWithDifferentMatricesBySizeShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a34a6e403b0fe20e494342a1b746999c2", null ],
    [ "GoodByeShouldPrintInTheConsoleProperMessage", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#ae8c434a0a6f0122305be9243ffc89113", null ],
    [ "GoodByeWhenMessageIsNullShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#a2aaf2f56748c63fc415270a0dca71e73", null ],
    [ "TestReadName", "class_minesweeper_1_1_unit_tests_1_1_game_1_1_u_i_manager_test.html#ad343db56504a5850b0e27d9ed6a4fafa", null ]
];