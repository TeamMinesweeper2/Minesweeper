var struct_minesweeper_1_1_lib_1_1_cell_pos =
[
    [ "CellPos", "struct_minesweeper_1_1_lib_1_1_cell_pos.html#afffd1dfab4648433c05d333afdbb563d", null ],
    [ "Col", "struct_minesweeper_1_1_lib_1_1_cell_pos.html#a0188f8cda7f5c928a7c0e3f252878da2", null ],
    [ "Row", "struct_minesweeper_1_1_lib_1_1_cell_pos.html#adb4d01bbbda584e580a188aa48173834", null ]
];