var class_minesweeper_1_1_unit_tests_1_1_common_1_1_shuffle_extension_test =
[
    [ "ShuffleWithMockedRandomGeneratorProviderShouldShuffleCorrectly", "class_minesweeper_1_1_unit_tests_1_1_common_1_1_shuffle_extension_test.html#ac54dc487b1443c5d008a7b286bcec350", null ],
    [ "ShuffleWithNullRandomGeneratorProviderShouldThrowAnException", "class_minesweeper_1_1_unit_tests_1_1_common_1_1_shuffle_extension_test.html#aabf781a5bba8bf96739784a4a627089b", null ],
    [ "TestInitialize", "class_minesweeper_1_1_unit_tests_1_1_common_1_1_shuffle_extension_test.html#a32a9cb1c4d9cff70ab62c80253cf0c51", null ]
];